#!/bin/bash

# Check if the file 'halangan.txt' exists
if [ -e "halangan.txt" ]; then
  # If it exists, print the error message
  echo "remove halangan.txt first"
else
  # If it doesn't exist, print 'DFM'
  echo "CEC{b45h_l4nGuAg3}"
fi
